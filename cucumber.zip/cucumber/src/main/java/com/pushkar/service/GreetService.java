package com.pushkar.service;

public class GreetService {
	
	public GreetService() {}

	public String greet(String name) {
		return "Hello " + name;
	}
}
