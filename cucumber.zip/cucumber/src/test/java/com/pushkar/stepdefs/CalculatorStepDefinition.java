package com.pushkar.stepdefs;

import static org.junit.Assert.assertEquals;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CalculatorStepDefinition {

	int a = 0;
	int b = 0;
	int result = 0;

	@Given("^user provides two numbers for addition$")
	public void user_provides_two_numbers_for_addition() {
		a = 20;
		b = 5;
	}
	
	@Given("^user provides two numbers for division$")
	public void user_provides_two_numbers_for_division() {
		a = 20;
		b = 5;
	}

	@When("^performs addition of two numbers$")
	public void performs_add_of_two_numbers() {
		result = a + b;
	}

	@Then("^addition result should be shown$")
	public void add_result_should_be_shown() {
		assertEquals(25, result);
	}
	
	@When("^performs division of two numbers$")
	public void performs_div_of_two_numbers() {
		result = a / b;
	}

	@Then("^division result should be shown$")
	public void div_result_should_be_shown() {
		assertEquals(4, result);
	}
	
}
