package com.pushkar.stepdefs;

import static org.junit.Assert.assertEquals;

import com.pushkar.service.GreetService;

import cucumber.api.java.Before;
import cucumber.api.java.en.Then;

public class GreetStepDefinition {

	private GreetService greetService;

	@Before
	public void setUp() {
		greetService = new GreetService();
	}

	@Then("^user wants to see greeting message$")
	public void greet() {
		assertEquals("Hello Pushkar", greetService.greet("Pushkar"));
	}

}
