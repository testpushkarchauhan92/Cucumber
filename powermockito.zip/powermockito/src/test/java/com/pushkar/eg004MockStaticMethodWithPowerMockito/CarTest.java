package com.pushkar.eg004MockStaticMethodWithPowerMockito;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest(Engine.class)
public class CarTest {

	@Test
	public void start_should_return_true_when_engine_ok() {
		PowerMockito.mockStatic(Engine.class);
		PowerMockito.when(Engine.start()).thenReturn(Engine.STARTED_OK);
		Car car = new Car();
		Assertions.assertTrue(car.start());
	}

}
