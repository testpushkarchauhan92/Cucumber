package com.pushkar.eg002MockInstanceMethodWithoutPowerMockito;

class EngineMock extends Engine {
	private int code;

	public void setReturnValue(int value) {
		code = value;
	}

	@Override
	public int start() {
		return code;
	}
}