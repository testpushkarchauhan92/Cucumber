//package com.pushkar.eg006MockPrivateVariablesWithPowerMockito;
//
//import static org.junit.Assert.assertTrue;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.powermock.api.mockito.PowerMockito;
//import org.powermock.modules.junit4.PowerMockRunner;
//
//@RunWith(PowerMockRunner.class)
//public class CarTest {
//	
//	@InjectMocks
//	Car car;
//	
//	@Mock(name="engine")
//	Engine engineMock;
//	
//	@Mock(name="engine2")
//	Engine engineMock2;
//	
//	@Test
//	public void start_should_return_true_when_engine_ok() {
//		PowerMockito.when(engineMock.start()).thenReturn(Engine.STARTED_OK);
//		assertTrue(car.start());
//	}
//
//}
