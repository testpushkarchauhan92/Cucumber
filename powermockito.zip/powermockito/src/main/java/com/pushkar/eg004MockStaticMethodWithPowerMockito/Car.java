package com.pushkar.eg004MockStaticMethodWithPowerMockito;

public class Car {
	
	public boolean start() {
		if (Engine.start() == Engine.STARTED_OK) {
			return true;
		}
		return false;
	}
}
