package com.pushkar.eg008SuppressConstructorsWithPowerMockito;


public class Vehicle {
	public Vehicle() {
		throw new RuntimeException();
	}

}
