package com.pushkar.eg006MockPrivateVariablesWithPowerMockito;

public class Car {
	private Engine engine;
	
	private Engine engine2;
	
	public Car() {
		engine = new Engine();
		engine2 = new Engine();
	}
	
	public boolean start() {
		if (engine.start() == Engine.STARTED_OK) {
			return true;
		}
		return false;
	}
}