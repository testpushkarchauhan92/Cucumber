package com.pushkar.stepdefs;

import static org.junit.Assert.assertEquals;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DivisionStepDefinition {

	int a = 0;
	int b = 0;
	int result = 0;

	@Given("^user provides two numbers$")
	public void user_provides_two_numbers() {
		a = 20;
		b = 5;
	}

	@When("^performs division of two numbers$")
	public void performs_division_of_two_numbers() {
		result = a / b;
	}

	@Then("^result should be shown$")
	public void result_should_be_shown() {
		assertEquals(4, result);
	}
	
	@Given("^user provides two numbers for modulus$")
	public void user_provides_two_numbers_for_modulus() {
		a = 20;
		b = 5;
	}

	@When("^performs modulus of two numbers$")
	public void performs_modulus_of_two_numbers() {
		result = a % b;
	}

	@Then("^result should be shown for modulus$")
	public void result_should_be_shown_for_modulus() {
		assertEquals(0, result);
	}

}
