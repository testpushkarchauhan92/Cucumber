package com.pushkar.stepdefs;

import static org.junit.Assert.assertEquals;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MultiplicationStepDefinition {

	int a = 0;
	int b = 0;
	int result = 0;

	@Given("^user provides two numbers$")
	public void user_provides_two_numbers() {
		a = 20;
		b = 5;
	}

	@When("^performs multiplication of two numbers$")
	public void performs_multiplication_of_two_numbers() {
		result = a * b;
	}

	@Then("^result should be shown$")
	public void result_should_be_shown() {
		assertEquals(100, result);
	}

}
