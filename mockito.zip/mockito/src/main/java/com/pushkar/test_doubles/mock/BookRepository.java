package com.pushkar.test_doubles.mock;

public interface BookRepository {
	void save(Book book);
}
