package com.pushkar.test_doubles.dummy;

public interface EmailService {
	void sendEmail(String message);
}
