package com.pushkar.test_doubles.dummy;

public class DummyEmailService implements EmailService {
	public void sendEmail(String message) {
		throw new AssertionError("Method not implemented !!!");
	}
}
