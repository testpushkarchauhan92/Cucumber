package com.example.stepDefinition;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.support.AnnotationConfigContextLoader;

import com.example.stepDefinition.CucumberSpringConfiguration.CucumberTestConfiguration;

import io.cucumber.java.Before;
import io.cucumber.spring.CucumberContextConfiguration;

@SpringBootTest
@CucumberContextConfiguration
@ContextConfiguration(classes = { CucumberTestConfiguration.class }, loader = AnnotationConfigContextLoader.class)
@TestPropertySource(value = "classpath:/config/test.properties")
public class CucumberSpringConfiguration {

	@Value("${fname}")
	private String fname;

	@Value("${isAdult}")
	private Boolean isAdult;

	@Before
	public void setup_cucumber_spring_context() {
		// Dummy method so cucumber will recognize this class as glue
		// and use its context configuration.
		System.out.println("==========================================");
		System.out.println("Property was " + fname);
		System.out.println("Property was " + isAdult);
		System.out.println("==========================================");
	}

	@Configuration
	@ComponentScan(basePackages = { "com.example.stepDefinition" })
	public static class CucumberTestConfiguration {

	}

}