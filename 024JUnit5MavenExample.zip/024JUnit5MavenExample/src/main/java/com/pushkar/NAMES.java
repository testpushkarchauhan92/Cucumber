package com.pushkar;

public enum NAMES {
	KK, PK, MK
}