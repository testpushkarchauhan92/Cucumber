package com.pushkar;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledIf;
import org.junit.jupiter.api.condition.EnabledIf;

public class Eg15CustomConditionsTest {

	@Test
	@EnabledIf("customCondition")
	void enabled() {
		System.out.println("enabled:Test execution depends on customCondition");
	}

	@Test
	@DisabledIf("customCondition")
	void disabled() {
		System.out.println("disabled:Test execution depends on customCondition");
	}

	boolean customCondition() {
		return true;
	}
}