package com.pushkar;
import static org.junit.jupiter.api.Assertions.assertEquals;
 
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
 
@RunWith(value = JUnitPlatform.class)
public class Eg26MyUtilsTest {
	
	private static MyUtils myUtils;
	
	@BeforeAll
	static void setUp() {
		myUtils = new MyUtils();
	}
	
	@Test
	void test_add_two_positive_numbers() {
		int actualResult = myUtils.add(20, 10);
		assertEquals(30, actualResult);
	}
	
	@Test
	void test_add_two_negative_numbers() {
		int actualResult = myUtils.add(-20, -10);
		assertEquals(-30, actualResult);
	}
	
	@Test
	void test_add_one_positive_and_one_negative_number() {
		int actualResult = myUtils.add(20, -10);
		assertEquals(10, actualResult);
	}
	
	@AfterAll
	static void tearDown() {
		myUtils = null;
	}
}