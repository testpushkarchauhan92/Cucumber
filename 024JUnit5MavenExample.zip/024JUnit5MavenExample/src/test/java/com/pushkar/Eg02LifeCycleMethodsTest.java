package com.pushkar;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Eg02LifeCycleMethodsTest {

	private static MyUtils myUtils;

	@BeforeAll
	static void setUp() {
		myUtils = new MyUtils();
		System.out.println("Test data setUp is done..");
	}

	@BeforeEach
	void beforeEach() {
		System.out.println("@BeforeEach is executed..");
	}

	@Test
	void testAdd() {
		int actual = myUtils.add(20, 10);
		assertEquals(30, actual);
		System.out.println("testAdd is done..");
	}

	@AfterEach
	void afterEach() {
		System.out.println("@AfterEach is executed..");
	}

	@AfterAll
	static void tearDown() {
		myUtils = null;
		System.out.println("Test data tearDown is done..");
	}

}
