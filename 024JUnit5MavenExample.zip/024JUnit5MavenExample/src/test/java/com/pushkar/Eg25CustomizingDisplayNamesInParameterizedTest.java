package com.pushkar;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.junit.jupiter.params.provider.CsvSource;

public class Eg25CustomizingDisplayNamesInParameterizedTest {

	@DisplayName("Display name of fruit container")
	@ParameterizedTest(name = "{index} => the rank of ''{0}'' is {1}")
	// @ParameterizedTest(name = "{arguments}")
	@CsvSource({ "apple, 1", "banana, 2", "'lemon, lime', 3" })
	void testWithCustomDisplayNames(String fruitName, int fruitRank) {
		assertTrue(!fruitName.isEmpty());
		assertTrue(fruitRank > 0);
	}

	@DisplayName("Display country name and population")
	@ParameterizedTest(name = "{index} => the population of ''{0}'' is {1} crore")
	@CsvFileSource(resources = "/myfile.csv", numLinesToSkip = 1)
	void testWithCustomCountryNames(String countryName, int population) {
		assertTrue(!countryName.isEmpty());
		assertTrue(population > 0);
	}
}