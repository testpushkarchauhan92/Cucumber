package com.pushkar;
import static org.junit.jupiter.api.Assertions.assertEquals;
 
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.DisabledOnOs;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;
 
public class Eg11OperatingSystemConditionsTest {
	
	private static MyUtils myUtils;
	
	@BeforeAll
	static void setUp() {
		myUtils = new MyUtils();
		System.out.println("Test data set up is done..");
	}
	
	
	@BeforeEach
	void beforeEach() {
		System.out.println("@BeforeEach is executed..");
	}
	
	@Test
	@EnabledOnOs(value = { OS.WINDOWS })
	void test_add_two_positive_numbers() {
		int actualResult = myUtils.add(20, 10);
		assertEquals(30, actualResult);
	}
	
	@Test
	@EnabledOnOs(value = { OS.WINDOWS,OS.LINUX })
	void test_add_two_negative_numbers() {
		int actualResult = myUtils.add(-20, -10);
		assertEquals(-30, actualResult);
	}
	
	@Test
	@DisabledOnOs(value = { OS.MAC })
	void test_add_one_positive_and_one_negative_number() {
		int actualResult = myUtils.add(20, -10);
		assertEquals(10, actualResult);
	}
	
	@AfterEach
	void afterEach() {
		System.out.println("@AfterEach is executed..");
	}
	
	@AfterAll
	static void tearDown() {
		myUtils = null;
		System.out.println("Test data teardown is done..");
	}
}