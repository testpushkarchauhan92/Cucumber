package com.pushkar;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

@Disabled("Disabled until bug #AFA-1234 id fixed")
class Eg06DisabledAnnotationTest {

	private static MyUtils myUtils;

	@BeforeAll
	static void setUp() {
		myUtils = new MyUtils();
		System.out.println("Test data setUp is done..");
	}

	@BeforeEach
	void beforeEach() {
		System.out.println("@BeforeEach is executed..");
	}

	@Test
	void test_add_two_positive_numbers() {
		int actual = myUtils.add(20, 10);
		assertEquals(30, actual);
	}

	@Test
	void test_add_two_negative_numbers() {
		int actual = myUtils.add(-20, -10);
		assertEquals(-30, actual);
	}

	@Test
	void test_add_one_positive_and_one_negative_number() {
		int actual = myUtils.add(20, -10);
		assertEquals(10, actual);
	}

	@AfterEach
	void afterEach() {
		System.out.println("@AfterEach is executed..");
	}

	@AfterAll
	static void tearDown() {
		myUtils = null;
		System.out.println("Test data tearDown is done..");
	}

}
