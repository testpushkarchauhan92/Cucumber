package com.pushkar;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Eg00StringUtilsTest {

	private static StringUtils stringUtils = null;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		System.out.println("setUpBeforeClass...");
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		System.out.println("tearDownAfterClass...");
	}

	@BeforeEach
	void setUp() throws Exception {
		stringUtils = new StringUtils();
		System.out.println("setUp...");
	}

	@Test
	void testReverse_emptyString() {
		Assertions.assertEquals("", stringUtils.reverse(""));
		System.out.println("testReverse...");
	}

	@Test
	void testReverse() {
		Assertions.assertEquals("cba", stringUtils.reverse("abc"));
		System.out.println("testReverse...");
	}

	@AfterEach
	void tearDown() throws Exception {
		stringUtils = null;
		System.out.println("tearDown...");
	}

}
