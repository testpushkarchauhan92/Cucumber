package com.pushkar;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.DynamicContainer.dynamicContainer;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.junit.jupiter.api.DynamicNode;
import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;

/**
 * Dynamic Tests JUnit Examples
 * 
 * @author Pushkar
 */
class Eg23DynamicTestsDemo {

	/**
	 * This will result in a JUnitException at Runtime because TestFactory has
	 * invalid return type
	 * 
	 * @return
	 */
	@TestFactory
	List<DynamicTest> dynamicTestsWithInvalidReturnType() {
		return Arrays.asList(dynamicTest("aaa", () -> MyUtils.isPalindrome("aaa")));
	}

	/**
	 * Dynamic Tests to check Stream of strings are Palindrome or not
	 * 
	 * @return
	 */

	@TestFactory
	Stream<DynamicTest> dynamicTestsForPalindromes() {

		return Stream.of("pop", "radar", "mom", "dad", "madam")
				.map(inputText -> dynamicTest(inputText, () -> assertTrue(MyUtils.isPalindrome(inputText))));
	}

	/**
	 * Dynamic Tests for Collection
	 * 
	 * @return
	 */
	@TestFactory
	Collection<DynamicTest> dynamicTestsFromCollection() {
		return Arrays.asList(dynamicTest("1st dynamic test", () -> assertTrue(MyUtils.isPalindrome("radar"))),
				dynamicTest("2nd dynamic test", () -> assertEquals(81, MyUtils.multiply(9, 9))));
	}

	/**
	 * Dynamic Tests for Iterable
	 * 
	 * @return
	 */
	@TestFactory
	Iterable<DynamicTest> dynamicTestsFromIterable() {
		return Arrays.asList(dynamicTest("3rd dynamic test", () -> assertTrue(MyUtils.isPalindrome("dad"))),
				dynamicTest("4th dynamic test", () -> assertEquals(9, MyUtils.multiply(3, 3))));
	}

	/**
	 * Dynamic Tests for Iterator
	 * 
	 * @return
	 */
	@TestFactory
	Iterator<DynamicTest> dynamicTestsFromIterator() {
		return Arrays.asList(dynamicTest("5th dynamic test", () -> assertTrue(MyUtils.isPalindrome("madam"))),
				dynamicTest("6th dynamic test", () -> assertEquals(25, MyUtils.multiply(5, 5)))).iterator();
	}

	/**
	 * Dynamic Tests for Array
	 * 
	 * @return
	 */
	@TestFactory
	DynamicTest[] dynamicTestsFromArray() {
		return new DynamicTest[] { dynamicTest("7th dynamic test", () -> assertTrue(MyUtils.isPalindrome("dad"))),
				dynamicTest("8th dynamic test", () -> assertEquals(16, MyUtils.multiply(4, 4))) };
	}

	/**
	 * Dynamic Tests for Stream. Generates tests for the first 5 even integers.
	 * 
	 * @return
	 */
	@TestFactory
	Stream<DynamicTest> dynamicTestsFromIntStream() {
		return IntStream.iterate(0, number -> number + 2).limit(5)
				.mapToObj(number -> dynamicTest("test" + number, () -> assertTrue(number % 2 == 0)));
	}

	/**
	 * Dynamic Tests for Stream.
	 * 
	 * @return
	 */
	@TestFactory
	Stream<DynamicNode> dynamicTestsWithContainers() {
		return Stream.of("A", "B", "C")
				.map(inputText -> dynamicContainer("Container " + inputText,
						Stream.of(dynamicTest("not null", () -> assertNotNull(inputText)),
								dynamicContainer("properties",
										Stream.of(dynamicTest("length > 0", () -> assertTrue(inputText.length() > 0)),
												dynamicTest("not empty", () -> assertFalse(inputText.isEmpty())))))));
	}

	@TestFactory
	DynamicNode dynamicTestFromSingleDynamicNode() {
		return dynamicTest("'mom' is a palindrome", () -> assertTrue(MyUtils.isPalindrome("mom")));
	}

	/**
	 * Dynamic Tests which returns Single DynamicNode
	 * 
	 * @return
	 */
	@TestFactory
	DynamicNode dynamicTestFromSingleNodeContainer() {
		return dynamicContainer("palindromes", Stream.of("pop", "radar", "mom", "dad")
				.map(inputText -> dynamicTest(inputText, () -> assertTrue(MyUtils.isPalindrome(inputText)))));
	}
}