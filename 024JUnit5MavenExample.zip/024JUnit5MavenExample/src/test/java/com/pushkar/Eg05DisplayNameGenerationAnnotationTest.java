package com.pushkar;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.lang.reflect.Method;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayNameGeneration;
import org.junit.jupiter.api.DisplayNameGenerator;
import org.junit.jupiter.api.Test;

@DisplayNameGeneration(value = Eg05DisplayNameGenerationAnnotationTest.CustomDisplayNameGenerator.class)
class Eg05DisplayNameGenerationAnnotationTest {

	private static MyUtils myUtils;

	@BeforeAll
	static void setUp() {
		myUtils = new MyUtils();
		System.out.println("Test data setUp is done..");
	}

	@BeforeEach
	void beforeEach() {
		System.out.println("@BeforeEach is executed..");
	}

	@Test
	void test_add_two_positive_numbers() {
		int actual = myUtils.add(20, 10);
		assertEquals(30, actual);
	}

	@Test
	void test_add_two_negative_numbers() {
		int actual = myUtils.add(-20, -10);
		assertEquals(-30, actual);
	}

	@Test
	void test_add_one_positive_and_one_negative_number() {
		int actual = myUtils.add(20, -10);
		assertEquals(10, actual);
	}

	@AfterEach
	void afterEach() {
		System.out.println("@AfterEach is executed..");
	}

	@AfterAll
	static void tearDown() {
		myUtils = null;
		System.out.println("Test data tearDown is done..");
	}

	static class CustomDisplayNameGenerator extends DisplayNameGenerator.ReplaceUnderscores {

		@Override
		public String generateDisplayNameForClass(Class<?> testClass) {
	//		return testClass.getName() + " Test Cases";
			return testClass.getCanonicalName()  + " Test Cases";
		}

		@Override
		public String generateDisplayNameForMethod(Class<?> testClass, Method testMethod) {
			String name = testClass.getSimpleName() + " " + testMethod.getName();
			return name.replace('_', ' ');
		}

		@Override
		public String generateDisplayNameForNestedClass(Class<?> nestedClass) {
			return super.generateDisplayNameForNestedClass(nestedClass);
		}

	}

}
