package com.pushkar;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

class Eg01MyUtilsTest {

	@Test
	void testAdd() {
		MyUtils myUtils = new MyUtils();
		int actual = myUtils.add(20, 30);
		assertEquals(50, actual);
	}

	@Test
	void testMultiply() {
		int actual = MyUtils.multiply(20, 30);
		assertEquals(600, actual);
	}

	@Test
	void testSquareOfNumber() {
		int actual = MyUtils.squareOfNumber(20);
		assertEquals(400, actual);
	}
	
	@Test
	void testPalindrome_positive1() {
		boolean actual = MyUtils.isPalindrome("refer");
		assertEquals(true, actual);
	}
	
	@Test
	void testPalindrome_positive2() {
		boolean actual = MyUtils.isPalindrome("madam");
		assertEquals(true, actual);
	}
	
	@Test
	void testPalindrome_negative1() {
		boolean actual = MyUtils.isPalindrome("rotory");
		assertEquals(false, actual);
	}

}
