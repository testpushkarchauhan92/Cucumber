package com.testSuite;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.SelectClasses;
import org.junit.runner.RunWith;

import com.pushkar.Eg27MyUtilsTest;
import com.pushkar.Eg28TestingAStack;
 
/**
 * @SelectPackages and @SelectClasses demo
 * @author Pushkar
 *
 */
@RunWith(JUnitPlatform.class)
//@SelectPackages(value = { "com.kkjavatutorials","com.kkjavatutorials.packageA" })
@SelectClasses( { Eg27MyUtilsTest.class, Eg28TestingAStack.class} )
public class Eg04TestSuiteWithSelectPackagesAndClassesExample {
}