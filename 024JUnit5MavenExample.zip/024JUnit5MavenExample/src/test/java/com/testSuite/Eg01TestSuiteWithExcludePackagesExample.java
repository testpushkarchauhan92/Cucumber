package com.testSuite;

import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.ExcludePackages;
import org.junit.platform.suite.api.SelectPackages;
import org.junit.runner.RunWith;

/**
 * @SelectPackages and @ExcludePackages demo
 * @author Pushkar
 *
 */
@RunWith(JUnitPlatform.class)
@SelectPackages(value = { "com.pushkar" })
@ExcludePackages(value = { "com.packageA" })
public class Eg01TestSuiteWithExcludePackagesExample {
}