package com.testSuite;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.ExcludeTags;
import org.junit.platform.suite.api.SelectPackages;
import org.junit.runner.RunWith;
/**
 * @SelectPackages,@IncludeTags and @ExcludeTags demo
 * @author Pushkar
 *
 */
@RunWith(JUnitPlatform.class)
@SelectPackages(value = { "com.pushkar"})
//@IncludeTags("dev")
@ExcludeTags("dev")
public class Eg03TestSuiteWithIncludeTagsExample {
}