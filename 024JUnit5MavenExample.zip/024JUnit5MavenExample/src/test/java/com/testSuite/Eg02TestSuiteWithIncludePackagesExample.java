package com.testSuite;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.platform.suite.api.IncludePackages;
import org.junit.platform.suite.api.SelectPackages;
import org.junit.runner.RunWith;
/**
 * @SelectPackages and @IncludePackages  demo
 * @author Pushkar
 *
 */
@RunWith(JUnitPlatform.class)
@SelectPackages(value = { "com.pushkar"})
@IncludePackages(value = {"com.packageA"})
public class Eg02TestSuiteWithIncludePackagesExample {
}